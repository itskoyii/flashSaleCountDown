let timeRemaining = 10;
let timerElement = document.getElementById("timer");

function countdown(){
  timeRemaining = timeRemaining - 1
  if (timeRemaining <= 0) {
    timerElement.innerText = "TIME IS UP!";
  } else {
    timerElement.innerText = timeRemaining
  }
}
setInterval (countdown, 1000);